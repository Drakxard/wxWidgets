#ifndef VENTANAPARAHISTORIAL_H
#define VENTANAPARAHISTORIAL_H
#include "wxfb_project.h"

class VentanaParaHistorial : public MyFrameHistorial {
	
private:
	
protected:
	
public:
	VentanaParaHistorial(wxWindow *parent=NULL);
	~VentanaParaHistorial();
};

#endif

