#include "../bibliotecario/bibliotecario.h"
#include "../alumno/alumno.h"
#include "../libro/libro.h"
#include "Historial.h"






bool Historial::AgregarNuevoRegistro(int IdBibliotecario){return true;}//se debe agregar automaticamente                                                          //una vez prestado el libro
bool Historial::EliminarRegistro(int IdRegistro){return true;};//Si quiere eliminar un libro o
//un alumno
	
	template <typename S>
		void Historial::Ver_Registro(int actual, vector<S>& v, string nombreArchivo){	
		//	if(Verificar_Existencia_Binario(actual,nombreArchivo)){
		//mostrar el historial de libros o usuarios
		//pero como lo hago?
	}
	
