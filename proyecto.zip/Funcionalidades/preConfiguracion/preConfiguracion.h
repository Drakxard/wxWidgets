#ifndef PRECONFIGURACION_H
#define PRECONFIGURACION_H
#include <iostream>
#include <cstring>
#include <iomanip>
#include <string>
#include <fstream>
#include <vector>
#include <algorithm>

#endif
