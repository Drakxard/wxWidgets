#ifndef VENTANAPRINCIPAL_H
#define VENTANAPRINCIPAL_H
#include "wxfb_project.h"
#include "VentanaParaBibliotecario.h"
#include "Funcionalidades/system/system.h"


class VentanaPrincipal : public VentanaParaBibliotecario {
	
private:
	
protected:
	
public:
	VentanaPrincipal(wxWindow *parent=NULL);
	~VentanaPrincipal();

};

#endif

