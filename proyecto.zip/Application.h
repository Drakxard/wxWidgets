#ifndef APPLICATION_H
#define APPLICATION_H

#include <wx/app.h>

class Application : public wxApp {
public:
	virtual bool OnInit();
};

#endif
