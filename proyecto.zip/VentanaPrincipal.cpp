#include "VentanaPrincipal.h"
#include <string>
using namespace std;

VentanaPrincipal::VentanaPrincipal(wxWindow *parent) : VentanaParaBibliotecario(parent) {
	
}

VentanaPrincipal::~VentanaPrincipal() {
}



