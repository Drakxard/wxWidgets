#include "VentanaParaHistorial.h"

VentanaParaHistorial::VentanaParaHistorial(wxWindow *parent) : MyFrameHistorial(parent) {
	
}

VentanaParaHistorial::~VentanaParaHistorial() {
	
}

