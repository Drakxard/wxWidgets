#include "HistorialAyton.h"

HistorialAyton::HistorialAyton(wxWindow *parent) : MyDialogHistorialAyrton(parent) {
	
}

HistorialAyton::~HistorialAyton() {
	
}

