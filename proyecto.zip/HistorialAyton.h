#ifndef HISTORIALAYTON_H
#define HISTORIALAYTON_H
#include "wxfb_project.h"

class HistorialAyton : public MyDialogHistorialAyrton {
	
private:
	
protected:
	
public:
	HistorialAyton(wxWindow *parent=NULL);
	~HistorialAyton();
};

#endif

